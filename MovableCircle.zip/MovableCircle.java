	
public class MovableCircle implements Movable{
	private int radius;
	private MovablePoint center;
	public MovableCircle(){
		this.center = new MovablePoint();
		this.radius=0;
	}
	public MovableCircle(int x,int y,int xSpeed,int ySpeed,int radius){
		this.center = new MovablePoint(x,y,xSpeed,ySpeed);
		this.radius = radius;
		
	}
	public String toString(){
		String a = center.toString() + " radius :"+Integer.toString(radius);
		return a;
	}
	public void moveUp(){
		center.moveUp();
	}
	public void moveDown(){
		center.moveDown();
	}
	public void moveLeft(){
		center.moveLeft();
	}
	public void moveRight(){
		center.moveRight();
	}
	
}