class Main{
public static void main(String abir[]){
		MovableCircle a= new MovableCircle(23,34,2,2,5);
		a.moveUp();
		System.out.println(a.toString());
		a.moveDown();
		System.out.println(a.toString());
		a.moveLeft();
		System.out.println(a.toString());
		a.moveRight();
		System.out.println(a.toString());
	}
}