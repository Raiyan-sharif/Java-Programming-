
class MovablePoint implements Movable{
	private int x;
	private int y;
	private int xSpeed;
	private int ySpeed;
	MovablePoint(){
		this.x=0;
		this.y=0;
		this.xSpeed=0;
		this.ySpeed=0;
	}
	public MovablePoint(int x,int y,int xSpeed,int ySpeed){
		this.x = x;
		this.y = y;
		this.xSpeed = xSpeed;
		this.ySpeed = ySpeed;
	}
	public String toString(){
		String a ="("+ Integer.toString(x)+","+Integer.toString(y)+")";
		return a;
	}
	public void moveUp(){
		y = y + ySpeed ;
	}
	public void moveDown(){
		y = y - ySpeed;
	}
	public void moveLeft(){
		x = x - xSpeed;
	}
	public void moveRight(){
		x = x + xSpeed;
	}
	
	


	
}