public class Circle implements GeometricObject{
	protected double radius=1.0;
	
	public Circle(double radius){
		
		this.radius=radius;
	}
	
	
	
	public double getPerimeter(){
		
		double perimeter=2*3.1416*radius;
		return perimeter;
	}
	
	
	
	public double getArea(){
		
		double area=3.1416*(radius*radius);
		return area;
	}
}
	
	