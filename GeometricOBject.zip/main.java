
public class main
{
	public static void main(String[] args)
	{
		Circle c=new Circle(7.0);
		System.out.println(" Perimeter: " +c.getPerimeter());
		System.out.println(" Area: " +c.getArea());
		ResizableCircle r=new ResizableCircle(4.0);
		System.out.println(" resized value: " +r.resize(70));
		
	}
}