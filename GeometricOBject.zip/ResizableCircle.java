public class ResizableCircle extends Circle implements Resizable
{
	public ResizableCircle(double radius)
	{
		super(radius);
	}	
	public double resize(int percent)
	{
		double temp=(double)percent/100;
		radius=radius*temp;
		return radius;
	}
}
