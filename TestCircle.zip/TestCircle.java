
public class TestCircle{
	Circle c=new Circle();
	TestCircle(){
		c = new Circle();
		
	}
	TestCircle(Circle c){
		this.c = c;
		
	}
	public void display(Circle c){
		
		System.out.println("The radius is: "+c.getRadius());
		System.out.println("The color is: "+c.getColor());
		System.out.println("The area is: "+c.getArea());
	}
	
	
}